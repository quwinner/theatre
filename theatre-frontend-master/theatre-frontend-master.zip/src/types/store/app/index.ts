export interface AppState {
  isLoad: boolean
}
