# [Preview]()

**Site to view triсks and full stats on them**

React/Redux,TypeScript,Socket.io,Sass
